import pandas as pd

msg=pd.read_csv("survey_lung_cancer.csv", names=['AGE','ALCOHOL','PEER_PRESSURE','CHRONIC DISEASE','SMOKING','ANXIETY','WHEEZING','CHEST PAIN','FATIGUE','ALLERGY'])

print('Total instances in the dataset:', msg.shape[0])

# msg['labelnum']=msg.label.map({'pos' :1,"neg":0})

#print(msg)

X=msg

Y=pd.read_csv("survey_lung_cancer.csv", names=['LUNG_CANCER'])


#print(X)

#print(Y)


# Splitting the dataset into train and test data
from sklearn.model_selection import train_test_split

xtrain,xtest,ytrain, ytest=train_test_split(X,Y)


print('\nDataset is split into Training and Testing samples')

print('Total training instances:', ytrain.shape[0])

print('Total testing instances', ytest.shape[0])

# Output of count vectoriser is a sparse matrix

# CountVectorizer stands for 'feature extraction'

from sklearn.feature_extraction.text import CountVectorizer

count_vect = CountVectorizer()

xtrain_dtm = count_vect.fit_transform(xtrain) #Sparse matrix

xtest_dtm = count_vect.transform(xtest)

print("\nTotal features extracted using CountVectorizer:",xtrain_dtm.shape[1])




# Training Naive Bayes (NB) classifier on training data.
from sklearn.naive_bayes import MultinomialNB
clf=MultinomialNB().fit(xtrain_dtm, ytrain)
predicted=clf.predict(xtest_dtm)
#printing accuracy metrics

from sklearn import metrics

print('\nAccuracy metrics')
print('Accuracy of the classifer is', metrics.accuracy_score (ytest, predicted))
print(metrics.recall_score (ytest, predicted), '\nPrecison :',metrics.precision_score (ytest, predicted))
print('Confusion matrix')
print('= ')
print(metrics.confusion_matrix(ytest,predicted))